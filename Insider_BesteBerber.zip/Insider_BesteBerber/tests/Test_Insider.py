import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

# Tarayıcıyı başlatacak yardımcı fonksiyon
def get_driver(browser_name):
    if browser_name == "chrome":
        options = Options()
        options.add_argument("--start-maximized")
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    elif browser_name == "firefox":
        options = FirefoxOptions()
        options.add_argument("--start-maximized")
        driver = webdriver.Firefox(service=Service(GeckoDriverManager().install()), options=options)
    else:
        raise ValueError(f"Unsupported browser: {browser_name}")
    
    return driver

# Tarayıcı parametresi için pytest argümanı ekleme
def pytest_addoption(parser):
    parser.addoption(
        "--browser", action="store", default="chrome", help="Tarayıcıyı belirtin: chrome veya firefox"
    )

# Fixture tanımı
@pytest.fixture(scope="session")
def driver(request):
    browser_name = request.config.getoption("--browser")  # Terminal üzerinden gelen parametre
    driver = get_driver(browser_name)
    yield driver
    driver.quit()

# Screenshot alma fonksiyonu
def take_screenshot(driver, name):
    path = f"screenshots/{name}.png"
    os.makedirs("screenshots", exist_ok=True)
    driver.save_screenshot(path)
    print(f"📸 Screenshot saved: {path}")

# Sayfa yüklenmesini bekleme fonksiyonu
def wait_for_page_load(driver):
    """Sayfanın tamamen yüklendiğini kontrol eder"""
    wait = WebDriverWait(driver, 30)  # 30 saniye bekle
    wait.until(lambda driver: driver.execute_script('return document.readyState') == 'complete')

# Scroll işlemi
def scroll_into_view(driver, element):
    driver.execute_script("arguments[0].scrollIntoView({ behavior: 'smooth', block: 'start' });", element)
    time.sleep(2)  # Scroll sonrası biraz bekle

# Test fonksiyonu
def test_insider_ui_flow(driver):
    wait = WebDriverWait(driver, 10)

    try:
        # Sayfanın tamamen yüklenmesini bekle
        driver.get("https://useinsider.com/")
        wait_for_page_load(driver)
        print("Sayfa başarıyla yüklendi.")

        # Çerez kabul etme butonunu bekle ve tıkla
        try:
            # Sayfayı kaydırarak butonu bulmaya çalış
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            accept_cookies = wait.until(EC.element_to_be_clickable((By.ID, "wt-cli-accept-all-btn")))
            accept_cookies.click()
            print("Çerez kabul etme butonuna tıklandı.")
        except Exception as e:
            print("Çerez kabul etme butonu bulunamadı veya hata oluştu:", e)
            take_screenshot(driver, "cookie_acceptance_error")
            pytest.fail("Çerez kabul etme butonu tıklanamadı.")

        # Company > Careers
        company = wait.until(EC.presence_of_element_located((By.XPATH, '//a[contains(text(),"Company")]')))
        ActionChains(driver).move_to_element(company).perform()

        careers = wait.until(EC.element_to_be_clickable((By.XPATH, '//a[contains(text(),"Careers")]')))
        careers.click()
        time.sleep(2)
        assert "careers" in driver.current_url
        print("Careers sayfasına başarıyla geçildi.")

        # QA Sayfası → See all jobs
        driver.get("https://useinsider.com/careers/quality-assurance/")
        time.sleep(2)
        see_all = wait.until(EC.element_to_be_clickable((By.XPATH, '//a[contains(text(),"See all QA jobs")]')))
        see_all.click()
        time.sleep(10)

        # Filtreler - Quality Assurance departmanı otomatik seçili olduğu için bunu bekliyoruz
        dept_filter = wait.until(EC.presence_of_element_located((By.XPATH, '//span[@id="select2-filter-by-department-container"]')))
        dept_text = dept_filter.get_attribute("title")
        assert dept_text == "Quality Assurance", f"Departman beklenen 'Quality Assurance' değil, mevcut: {dept_text}"
        print("Filtreler başarıyla uygulandı.")

        # Şehirler filtresine tıkla
        loc_filter = wait.until(EC.element_to_be_clickable((By.XPATH, '//span[@id="select2-filter-by-location-container"]')))
        loc_filter.click()  # "All" kısmına tıklıyoruz

        # "Istanbul, Turkey" öğesini seç
        city_option = wait.until(EC.element_to_be_clickable((By.XPATH, '//li[text()="Istanbul, Turkiye"]')))
        city_option.click()
        time.sleep(3)

        # Filtre sonrası scroll ekleyelim
        jobs_list = wait.until(EC.presence_of_element_located((By.ID, "jobs-list")))
        scroll_into_view(driver, jobs_list)

        # İş ilanlarını listele
        jobs = jobs_list.find_elements(By.CLASS_NAME, "position-list-item")
        print(f"Toplam iş ilanı sayısı: {len(jobs)}")

        assert len(jobs) > 0, "Hiç iş ilanı bulunamadı."
        print(f"Toplam {len(jobs)} iş ilanı bulundu.")

        # İş ilanlarını kontrol et
        for idx, job in enumerate(jobs):
            try:
                title = job.find_element(By.CLASS_NAME, 'position-title').text.strip()
                dept = job.find_element(By.CLASS_NAME, 'position-department').text.strip()
                loc = job.find_element(By.CLASS_NAME, 'position-location').text.strip()

                print(f"\nİlan {idx+1}:")
                print(f"Başlık: {title}")
                print(f"Departman: {dept}")
                print(f"Şehir: {loc}")

                assert "Quality Assurance" in dept, f"Departman 'Quality Assurance' değil, mevcut: {dept}"
                assert "Istanbul, Turkiye" in loc, f"Şehir 'Istanbul, Turkiye' değil, mevcut: {loc}"
                assert title, "Başlık boş olamaz!"
                print(f"İlan {idx+1} başarılı bir şekilde kontrol edildi.")

            except Exception as e:
                take_screenshot(driver, f"job_data_error_{idx+1}")
                print(f"Bu ilana ait veri alınamadı: {e}")
                pytest.fail(f"İlan {idx+1} kontrol edilemedi: {e}")

        # İlk iş ilanına tıkla ve yönlendirmeyi kontrol et
        first_link = jobs[0].find_element(By.TAG_NAME, "a")
        first_link.click()
        driver.switch_to.window(driver.window_handles[1])
        WebDriverWait(driver, 10).until(lambda d: "lever.co" in d.current_url)
        assert "lever.co" in driver.current_url
        print("İlk iş ilanına tıklandı ve yönlendirme başarıyla kontrol edildi.")

    except Exception as e:
        take_screenshot(driver, "error_state")
        print(f"Test sırasında hata oluştu: {e}")
        pytest.fail(f"Test başarısız oldu: {e}")

